
public class Mainn {
    public static void main(String[] args) {
       new GUI();
    }
}
